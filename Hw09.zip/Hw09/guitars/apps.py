from django.apps import AppConfig


class GuitarsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'guitars'
